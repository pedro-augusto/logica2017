<?php

	$idade= array(14,90,15,89,47);

	for ($i=0; $i <= 4; $i++) { 
		print($idade[$i]."\n");
	}

  ?>