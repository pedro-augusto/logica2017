<?php

	$nome= array("Jurema","Adalberto","Edvige","Desamer","Mcdonaldson");

	for ($i=0; $i <= 4; $i++) { 
		print($nome[$i]. "\n");
	}


  ?>