<?php

	$nome= array("Jurema","Adalberto","Edvige","Desamer","Mcdonaldson");
	$idade= array(14,90,15,89,47);

	for ($i=0; $i <= 4 ; $i++) { 
		print($nome[$i]." - ".$idade[$i]."\n");
	}


  ?>